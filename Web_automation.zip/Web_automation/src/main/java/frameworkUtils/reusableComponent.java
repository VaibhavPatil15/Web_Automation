package frameworkUtils;

public interface reusableComponent {
	public static String URL = "https://demo.guru99.com/test/newtours/register.php";
	public static String browserType = "chrome";
	public static String chrome_extc = "webdriver.chrome.driver";
	public static String edge_exte = "webdriver.edge.driver";
	public static String chrome_path = "C:\\Users\\Vp671\\eclipse-workspace\\Web_automation\\Browser\\chromedriver.exe";
	public static String edge_path = "C:\\Users\\Vp671\\eclipse-workspace\\Web_automation\\Browser\\msedgedriver.exe";
}
