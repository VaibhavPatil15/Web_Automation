package browser;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

// Author: VaibhavP
import frameworkUtils.reusableComponent;

public class browserInitializer {
	// To lanuch Specific Browser
	static WebDriver driver;

	public static WebDriver readDriverUtils() throws Exception {
		if (reusableComponent.browserType == "chrome") {
			System.setProperty(reusableComponent.chrome_extc, reusableComponent.chrome_path);
			driver = new ChromeDriver();
		} else if (reusableComponent.browserType == "edge") {
			System.setProperty(reusableComponent.edge_exte, reusableComponent.edge_path);
			driver = new EdgeDriver();
		} else
			System.out.println("No Correct Browser Found");
		driver.get(reusableComponent.URL);
		return driver;
	}

}
