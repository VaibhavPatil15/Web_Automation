package testdata;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import browser.browserInitializer;

@Test
public class createUser {
	public static void launchBrowser() throws Exception {
		WebDriver driver = browserInitializer.readDriverUtils();

	}
}
